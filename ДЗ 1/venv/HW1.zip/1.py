num_1 = 1
num_2 = 2
st_1 = 'Hello'
st_2 = 'world!'
print('Число 1:', num_1)
print('Число 2:', num_2)
print(f'Получилась строка: {st_1} {st_2}')
num_1 = int(input('Введите число: '))
print('Вы ввели - ', num_1)
st_1 = input('Введите любые символы: ')
print('Получилась строка :', st_1)


