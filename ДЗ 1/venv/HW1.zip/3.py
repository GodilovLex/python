n = input('Введите цифры: ')
print('n + nn + nnn получится: ', int(n) + int(n+n) + int(n+n+n))